# importing required libraries
from PyQt5.QtCore import *
from PyQt5.QtWidgets import *
from PyQt5.QtGui import *
from PyQt5.QtWebEngineWidgets import *
from PyQt5.QtPrintSupport import *
import json
import os
import sys


# main window
class MainWindow(QMainWindow):

    # constructor
    def __init__(self, *args, **kwargs):
        super(MainWindow, self).__init__(*args, **kwargs)

        # creating a tab widget
        self.tabs = QTabWidget()

        # making document mode true
        self.tabs.setDocumentMode(True)

        # adding action when double clicked
        self.tabs.tabBarDoubleClicked.connect(self.tab_open_doubleclick)

        # adding action when tab is changed
        self.tabs.currentChanged.connect(self.current_tab_changed)

        # making tabs closeable
        self.tabs.setTabsClosable(True)

        # adding action when tab close is requested
        self.tabs.tabCloseRequested.connect(self.close_current_tab)

        # making tabs as central widget
        self.setCentralWidget(self.tabs)

        self.topLevelDomains = []
        plik = open("topLevelDomains.json", "r")
        self.topLevelDomains = json.load(plik)
        plik.close()

        # creating a status bar
        self.status = QStatusBar()

        # setting status bar to the main window
        self.setStatusBar(self.status)

        # creating a tool bar for navigation
        navtb = QToolBar("Navigation")

        # adding tool bar tot he main window
        self.addToolBar(navtb)

        # creating home action
        home_btn = QAction(QIcon("Logo.png"), "Home", self)
        home_btn.setStatusTip("Idź na stronę domową")

        # adding action to home button
        home_btn.triggered.connect(self.navigate_home)
        navtb.addAction(home_btn)

        # creating back action
        back_btn = QAction(QIcon("back button.png"), "Back", self)

        # setting status tip
        back_btn.setStatusTip("Back to previous page")

        # adding action to back button
        # making current tab to go back
        back_btn.triggered.connect(lambda: self.tabs.currentWidget().back())

        # adding this to the navigation tool bar
        navtb.addAction(back_btn)

        # similarly adding next button
        next_btn = QAction(QIcon("forward button.png"), "Forward", self)
        next_btn.setStatusTip("Forward to next page")
        next_btn.triggered.connect(lambda: self.tabs.currentWidget().forward())
        navtb.addAction(next_btn)

        # similarly adding reload button
        reload_btn = QAction(QIcon("refresh.png"), "Reload", self)
        reload_btn.setStatusTip("Załaduj stronę od nowa")
        reload_btn.triggered.connect(lambda: self.tabs.currentWidget().reload())
        navtb.addAction(reload_btn)

        # adding a separator
        navtb.addSeparator()

        # creating a line edit widget for URL
        self.urlbar = QLineEdit()

        # adding action to line edit when return key is pressed
        self.urlbar.returnPressed.connect(self.search)

        # adding line edit to tool bar
        navtb.addWidget(self.urlbar)

        navtb.addSeparator()

        # similarly adding stop action
        stop_btn = QAction(QIcon("stop.png"), "Stop", self)
        stop_btn.setStatusTip("Stop loading current page")
        stop_btn.triggered.connect(lambda: self.tabs.currentWidget().stop())
        navtb.addAction(stop_btn)

        add_btn = QAction(QIcon("newTab.png"), "New Tab", self)
        add_btn.setStatusTip("Nowa karta")
        add_btn.triggered.connect(
            lambda: self.add_new_tab(QUrl('file://' + os.path.dirname(os.path.abspath(__file__)) + "/main.png"),
                                     'Homepage'))
        navtb.addAction(add_btn)

        # creating first tab
        self.add_new_tab(QUrl('file://' + os.path.dirname(os.path.abspath(__file__)) + "/main.png"), 'Homepage')

        # showing all the components
        self.showMaximized()

        # setting window title
        self.setWindowTitle("Panther Browser")

    # method for adding new tab
    def add_new_tab(self, qurl=None, label="How?"):

        # if url is blank
        if qurl is None:
            qurl = QUrl('file://' + os.path.dirname(os.path.abspath(__file__)) + "/main.png")

        # creating a QWebEngineView object
        browser = QWebEngineView()

        # setting url to browser
        browser.setUrl(qurl)

        # setting tab index
        i = self.tabs.addTab(browser, label)
        self.tabs.setCurrentIndex(i)

        # adding action to the browser when url is changed
        # update the url
        browser.urlChanged.connect(lambda qurl, browser=browser:
                                   self.urlChanged(qurl, browser))

        # adding action to the browser when loading is finished
        # set the tab title
        browser.loadFinished.connect(lambda _, i=i, browser=browser:
                                     self.tabs.setTabText(i, browser.page().title()))

    # when double clicked is pressed on tabs
    def tab_open_doubleclick(self, i):

        # checking index i.e
        # No tab under the click
        if i == -1:
            # creating a new tab
            self.add_new_tab()

    # wen tab is changed
    def current_tab_changed(self, i):

        # get the curl
        qurl = self.tabs.currentWidget().url()

        # update the url
        self.urlChanged(qurl, self.tabs.currentWidget())

    # when tab is closed
    def close_current_tab(self, i):

        # if there is only one tab
        if self.tabs.count() < 2:
            # do nothing
            return

        # else remove the tab
        self.tabs.removeTab(i)

    # action to go to home
    def navigate_home(self):

        # go to google
        self.tabs.currentWidget().setUrl(QUrl('file://' + os.path.dirname(os.path.abspath(__file__)) + "/main.png"))

    # method for navigate to url
    def search(self):
        url = self.urlbar.text()
        url = self.filterUrl(url, self.tabs.currentWidget())
        self.tabs.currentWidget().setUrl(QUrl(url))

    def filterUrl(self, url: str, browser):

        if url == 'home':
            url = "https://duckduckgo.com"
            return url
        for d in self.topLevelDomains:
            if url.__contains__(d) and not (url.__contains__("://")):
                url = "http://" + url
                return url
        if not (url.__contains__("://")):
            url = "https://duckduckgo.com/?q=" + url + "&t=h_&ia=web"
            return url
        return url

    def urlChanged(self, url: str, browser):
        if browser != self.tabs.currentWidget():
            return
        self.urlbar.setText(url.toString())
        self.urlbar.setCursorPosition(0)
    # method to update the url


print(os.path.dirname(os.path.abspath(__file__)))

# creating a PyQt5 application
app = QApplication(sys.argv)

# setting name to the application
app.setApplicationName("Panther Browser")
app.setStyle('Fusion')

# creating MainWindow object
window = MainWindow()

# loop
app.exec_()