import requests
import os
import wget
url = ""
def check_updates():
    currentVersion = get_version()

def get_version():
    vfile = open("version.txt", "r")
    contents = vfile.readline(1)
    print(contents)
    version = contents.split(".")
    return version

def check_version():
    pass

def update():
    wget.download()